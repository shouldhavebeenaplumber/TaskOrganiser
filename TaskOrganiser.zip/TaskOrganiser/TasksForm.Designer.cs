﻿
namespace TaskOrganiser
{
    partial class TasksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.cbTaskType = new System.Windows.Forms.ComboBox();
            this.btnAddTask = new System.Windows.Forms.Button();
            this.tbTaskName = new System.Windows.Forms.TextBox();
            this.listViewTasks = new System.Windows.Forms.ListView();
            this.columnID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTaskName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTaskType = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnTime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tbTaskDate = new System.Windows.Forms.TextBox();
            this.labelTaskName = new System.Windows.Forms.Label();
            this.labelTaskType = new System.Windows.Forms.Label();
            this.labelTaskDate = new System.Windows.Forms.Label();
            this.labelTaskTime = new System.Windows.Forms.Label();
            this.tbTaskTime = new System.Windows.Forms.TextBox();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.cbSortBy = new System.Windows.Forms.ComboBox();
            this.tbBanner = new System.Windows.Forms.TextBox();
            this.btnShowAllTasks = new System.Windows.Forms.Button();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.objectListView1 = new BrightIdeasSoftware.ObjectListView();
            this.olvColumn1 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn2 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn3 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn4 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.olvColumn5 = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.objectListView1)).BeginInit();
            this.SuspendLayout();
            // 
            // cbTaskType
            // 
            this.cbTaskType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTaskType.FormattingEnabled = true;
            this.cbTaskType.Items.AddRange(new object[] {
            "Personal",
            "Work"});
            this.cbTaskType.Location = new System.Drawing.Point(82, 478);
            this.cbTaskType.Name = "cbTaskType";
            this.cbTaskType.Size = new System.Drawing.Size(61, 21);
            this.cbTaskType.TabIndex = 0;
            this.toolTip1.SetToolTip(this.cbTaskType, "Select task type");
            // 
            // btnAddTask
            // 
            this.btnAddTask.Location = new System.Drawing.Point(148, 477);
            this.btnAddTask.Name = "btnAddTask";
            this.btnAddTask.Size = new System.Drawing.Size(65, 23);
            this.btnAddTask.TabIndex = 1;
            this.btnAddTask.Text = "Add Task";
            this.btnAddTask.UseVisualStyleBackColor = true;
            this.btnAddTask.Click += new System.EventHandler(this.btnAddTask_Click);
            // 
            // tbTaskName
            // 
            this.tbTaskName.Location = new System.Drawing.Point(82, 400);
            this.tbTaskName.Name = "tbTaskName";
            this.tbTaskName.Size = new System.Drawing.Size(131, 20);
            this.tbTaskName.TabIndex = 2;
            // 
            // listViewTasks
            // 
            this.listViewTasks.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnID,
            this.columnTaskName,
            this.columnTaskType,
            this.columnDate,
            this.columnTime});
            this.listViewTasks.HideSelection = false;
            this.listViewTasks.Location = new System.Drawing.Point(12, 25);
            this.listViewTasks.Name = "listViewTasks";
            this.listViewTasks.Size = new System.Drawing.Size(391, 342);
            this.listViewTasks.TabIndex = 3;
            this.listViewTasks.UseCompatibleStateImageBehavior = false;
            this.listViewTasks.View = System.Windows.Forms.View.Details;
            this.listViewTasks.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listViewTasks_MouseDoubleClick);
            // 
            // columnID
            // 
            this.columnID.Text = "ID#";
            this.columnID.Width = 32;
            // 
            // columnTaskName
            // 
            this.columnTaskName.Text = "Task Name";
            this.columnTaskName.Width = 143;
            // 
            // columnTaskType
            // 
            this.columnTaskType.Text = "Type";
            // 
            // columnDate
            // 
            this.columnDate.Text = "Date";
            this.columnDate.Width = 91;
            // 
            // columnTime
            // 
            this.columnTime.Text = "Time";
            // 
            // tbTaskDate
            // 
            this.tbTaskDate.Location = new System.Drawing.Point(82, 426);
            this.tbTaskDate.Name = "tbTaskDate";
            this.tbTaskDate.Size = new System.Drawing.Size(131, 20);
            this.tbTaskDate.TabIndex = 4;
            // 
            // labelTaskName
            // 
            this.labelTaskName.AutoSize = true;
            this.labelTaskName.Location = new System.Drawing.Point(20, 403);
            this.labelTaskName.Name = "labelTaskName";
            this.labelTaskName.Size = new System.Drawing.Size(62, 13);
            this.labelTaskName.TabIndex = 5;
            this.labelTaskName.Text = "Task Name";
            // 
            // labelTaskType
            // 
            this.labelTaskType.AutoSize = true;
            this.labelTaskType.Location = new System.Drawing.Point(24, 482);
            this.labelTaskType.Name = "labelTaskType";
            this.labelTaskType.Size = new System.Drawing.Size(58, 13);
            this.labelTaskType.TabIndex = 6;
            this.labelTaskType.Text = "Task Type";
            // 
            // labelTaskDate
            // 
            this.labelTaskDate.AutoSize = true;
            this.labelTaskDate.Location = new System.Drawing.Point(52, 430);
            this.labelTaskDate.Name = "labelTaskDate";
            this.labelTaskDate.Size = new System.Drawing.Size(30, 13);
            this.labelTaskDate.TabIndex = 7;
            this.labelTaskDate.Text = "Date";
            // 
            // labelTaskTime
            // 
            this.labelTaskTime.AutoSize = true;
            this.labelTaskTime.Location = new System.Drawing.Point(52, 456);
            this.labelTaskTime.Name = "labelTaskTime";
            this.labelTaskTime.Size = new System.Drawing.Size(30, 13);
            this.labelTaskTime.TabIndex = 9;
            this.labelTaskTime.Text = "Time";
            // 
            // tbTaskTime
            // 
            this.tbTaskTime.Location = new System.Drawing.Point(82, 452);
            this.tbTaskTime.Name = "tbTaskTime";
            this.tbTaskTime.Size = new System.Drawing.Size(131, 20);
            this.tbTaskTime.TabIndex = 8;
            // 
            // btnSaveFile
            // 
            this.btnSaveFile.Location = new System.Drawing.Point(315, 400);
            this.btnSaveFile.Name = "btnSaveFile";
            this.btnSaveFile.Size = new System.Drawing.Size(89, 23);
            this.btnSaveFile.TabIndex = 11;
            this.btnSaveFile.Text = "Save";
            this.toolTip1.SetToolTip(this.btnSaveFile, "Save tasks to file");
            this.btnSaveFile.UseVisualStyleBackColor = true;
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(220, 400);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(89, 23);
            this.btnOpen.TabIndex = 12;
            this.btnOpen.Text = "Open";
            this.toolTip1.SetToolTip(this.btnOpen, "Open tasks from file");
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // cbSortBy
            // 
            this.cbSortBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbSortBy.FormattingEnabled = true;
            this.cbSortBy.Items.AddRange(new object[] {
            "ID",
            "Name",
            "Type",
            "Date",
            "Time"});
            this.cbSortBy.Location = new System.Drawing.Point(315, 456);
            this.cbSortBy.Name = "cbSortBy";
            this.cbSortBy.Size = new System.Drawing.Size(89, 21);
            this.cbSortBy.TabIndex = 13;
            this.toolTip1.SetToolTip(this.cbSortBy, "Select a sort criteria to sort tasks");
            this.cbSortBy.SelectedIndexChanged += new System.EventHandler(this.cbSortBy_SelectedIndexChanged);
            // 
            // tbBanner
            // 
            this.tbBanner.Location = new System.Drawing.Point(12, 373);
            this.tbBanner.Name = "tbBanner";
            this.tbBanner.Size = new System.Drawing.Size(391, 20);
            this.tbBanner.TabIndex = 16;
            // 
            // btnShowAllTasks
            // 
            this.btnShowAllTasks.Location = new System.Drawing.Point(220, 427);
            this.btnShowAllTasks.Name = "btnShowAllTasks";
            this.btnShowAllTasks.Size = new System.Drawing.Size(184, 23);
            this.btnShowAllTasks.TabIndex = 17;
            this.btnShowAllTasks.Text = "All Tasks";
            this.toolTip1.SetToolTip(this.btnShowAllTasks, "Show all tasks");
            this.btnShowAllTasks.UseVisualStyleBackColor = true;
            this.btnShowAllTasks.Click += new System.EventHandler(this.btnShowAllTasks_Click);
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(315, 483);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(89, 20);
            this.tbSearch.TabIndex = 18;
            this.toolTip1.SetToolTip(this.tbSearch, "Press Enter to search");
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(271, 460);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 19;
            this.label1.Text = "Sort By:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(271, 485);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 20;
            this.label2.Text = "Search:";
            // 
            // objectListView1
            // 
            this.objectListView1.AllColumns.Add(this.olvColumn1);
            this.objectListView1.AllColumns.Add(this.olvColumn2);
            this.objectListView1.AllColumns.Add(this.olvColumn3);
            this.objectListView1.AllColumns.Add(this.olvColumn4);
            this.objectListView1.AllColumns.Add(this.olvColumn5);
            this.objectListView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.olvColumn1,
            this.olvColumn2,
            this.olvColumn3,
            this.olvColumn4,
            this.olvColumn5});
            this.objectListView1.HideSelection = false;
            this.objectListView1.Location = new System.Drawing.Point(409, 25);
            this.objectListView1.Name = "objectListView1";
            this.objectListView1.Size = new System.Drawing.Size(391, 342);
            this.objectListView1.TabIndex = 21;
            this.objectListView1.UseCompatibleStateImageBehavior = false;
            this.objectListView1.View = System.Windows.Forms.View.Details;
            this.objectListView1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.objectListView1_MouseDoubleClick);
            // 
            // olvColumn1
            // 
            this.olvColumn1.AspectName = "getTaskName";
            this.olvColumn1.DisplayIndex = 1;
            this.olvColumn1.Text = "Name";
            this.olvColumn1.Width = 165;
            // 
            // olvColumn2
            // 
            this.olvColumn2.AspectName = "getID";
            this.olvColumn2.DisplayIndex = 0;
            this.olvColumn2.Text = "ID#";
            this.olvColumn2.Width = 34;
            // 
            // olvColumn3
            // 
            this.olvColumn3.AspectName = "getTaskType";
            this.olvColumn3.Text = "Type";
            // 
            // olvColumn4
            // 
            this.olvColumn4.AspectName = "getDate";
            this.olvColumn4.Text = "Date";
            // 
            // olvColumn5
            // 
            this.olvColumn5.AspectName = "getTime";
            this.olvColumn5.Text = "Time";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Regular ListView";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(406, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 13);
            this.label4.TabIndex = 23;
            this.label4.Text = "ObjectListView";
            // 
            // TasksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 514);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.objectListView1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tbSearch);
            this.Controls.Add(this.btnShowAllTasks);
            this.Controls.Add(this.tbBanner);
            this.Controls.Add(this.cbSortBy);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.btnSaveFile);
            this.Controls.Add(this.labelTaskTime);
            this.Controls.Add(this.tbTaskTime);
            this.Controls.Add(this.labelTaskDate);
            this.Controls.Add(this.labelTaskType);
            this.Controls.Add(this.labelTaskName);
            this.Controls.Add(this.tbTaskDate);
            this.Controls.Add(this.listViewTasks);
            this.Controls.Add(this.tbTaskName);
            this.Controls.Add(this.btnAddTask);
            this.Controls.Add(this.cbTaskType);
            this.Name = "TasksForm";
            this.Text = "ListView vs ObjectListView Comparison: Tasks App";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TasksForm_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.objectListView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbTaskType;
        private System.Windows.Forms.Button btnAddTask;
        private System.Windows.Forms.TextBox tbTaskName;
        private System.Windows.Forms.ListView listViewTasks;
        private System.Windows.Forms.ColumnHeader columnTaskName;
        private System.Windows.Forms.ColumnHeader columnTaskType;
        private System.Windows.Forms.ColumnHeader columnDate;
        private System.Windows.Forms.ColumnHeader columnTime;
        private System.Windows.Forms.TextBox tbTaskDate;
        private System.Windows.Forms.Label labelTaskName;
        private System.Windows.Forms.Label labelTaskType;
        private System.Windows.Forms.Label labelTaskDate;
        private System.Windows.Forms.Label labelTaskTime;
        private System.Windows.Forms.TextBox tbTaskTime;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.ComboBox cbSortBy;
        private System.Windows.Forms.TextBox tbBanner;
        private System.Windows.Forms.Button btnShowAllTasks;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.ColumnHeader columnID;
        private BrightIdeasSoftware.ObjectListView objectListView1;
        private BrightIdeasSoftware.OLVColumn olvColumn2;
        private BrightIdeasSoftware.OLVColumn olvColumn1;
        private BrightIdeasSoftware.OLVColumn olvColumn3;
        private BrightIdeasSoftware.OLVColumn olvColumn4;
        private BrightIdeasSoftware.OLVColumn olvColumn5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
    }
}

