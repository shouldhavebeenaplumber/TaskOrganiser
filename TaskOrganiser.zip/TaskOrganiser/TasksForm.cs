﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Security.Cryptography;
using System.Windows.Forms;
using MessageBox = System.Windows.Forms.MessageBox;
using OpenFileDialog = System.Windows.Forms.OpenFileDialog;
using SaveFileDialog = System.Windows.Forms.SaveFileDialog;

/*
 * Nathan Tai
 * P148535
 * 14/06/2021
 * Programming III: Activity 3
 * Final Project
 * 
 * Task organiser app with hash file verification.
 * Comparison of third party ObjectListView with windows listview.
 * Amount of work required to emulate the functionality of 
 * 3rd party library with windows listview is compared.
 * 
 * ObjectListView advantages:
 * 
 * Search by partial match
 * Sorting built into columns, enabled by clicking column
 * Objects from collection displayed automatically by setting aspect of column to name of variable
 * Task details collapsible
 * Can exclude columns from view by right-clicking and selecting
 * Each attribute can be main focus, instead of having one main attribute and unselectable subitems
 * Can delete by any parameter
 * Easy reverse sorting
 */

namespace TaskOrganiser
{
    public partial class TasksForm : Form
    {
        #region Globals

        //For last saved hash
        byte[] myHash;

        //Filepath to write hash
        string hashStoredFilePath = "hashStored.bin";

        //For banner display
        readonly string allTasks = "Showing: All Tasks";
        readonly string searchTasks = "Showing: Search Results";

        //Default sort criteria, sort by DATE.
        //Can be changed by using cb.SortBy (ComboBox on the TasksForm).
        string currentSortBy = "date";

        //List for tasks
        List<Task> taskList = new List<Task>();

        //List for searching, passed into main list when done
        List<Task> searchResults = new List<Task>();

        //Instantiate task class
        Task task = new Task();

        #endregion Globals

        public TasksForm()
        {
            InitializeComponent();

            //Get existing hash
            myHash = File.ReadAllBytes(hashStoredFilePath);
        }

        #region Methods

        public void ClearInputTextBoxes()
        {
            tbTaskName.Clear();
            tbTaskDate.Clear();
            tbTaskTime.Clear();
        }

        private void AddTask()
        {
            if ((!string.IsNullOrEmpty(tbTaskName.Text))
                && (!string.IsNullOrEmpty(cbTaskType.Text))
                && (!string.IsNullOrEmpty(tbTaskDate.Text))
                && (!string.IsNullOrEmpty(tbTaskTime.Text)))
            {
                Task task = new Task();
                task.setID(taskList.Count);
                task.setTaskName(tbTaskName.Text);
                task.setTaskType(cbTaskType.Text);
                task.setDate(tbTaskDate.Text);
                task.setTime(tbTaskTime.Text);

                taskList.Add(task);

                InsertionSort(currentSortBy, taskList);
                DisplayAllTasks(taskList);
                ClearInputTextBoxes();

                //ObjectListView
                this.objectListView1.SetObjects(taskList);
            }
            else
            {
                MessageBox.Show("One or more fields empty");
            }
        }

        public void UpdateBannerAllTasks()
        {
            tbBanner.Text = "Showing: All Tasks";
        }

        public void UpdateBannerSearchResults()
        {
            tbBanner.Text = "Showing: Search Results";
        }

        //For testing
        public void DisplayTask(Task task)
        {
            string id = task.getID().ToString();
            string name = task.getTaskName();
            string type = task.getTaskType();
            string date = task.getDate();
            string time = task.getTime();
            listViewTasks.Items.Add(id).SubItems.AddRange(new string[] { name, type, date, time });
        }

       /*
        * Display tasks in listview.
        * Amount of code required to achieve this in ObjectListView:
        * this.objectListView1.SetObjects(taskList);
        */
        public void DisplayAllTasks(List<Task> taskList)
        {
            listViewTasks.Items.Clear();

            foreach (Task task in taskList)
            {
                string id = task.getID().ToString();
                string name = task.getTaskName();
                string type = task.getTaskType();
                string date = task.getDate();
                string time = task.getTime();
                listViewTasks.Items.Add(id).SubItems.AddRange(new string[] { name, type, date, time });
            }
        }

        //Returns multiple results by any parameter.
        /* 
         * Amount of code to achieve the same in ObjectListView (plus search by partial match):
         * objectListView1.SelectedItem = (BrightIdeasSoftware.OLVListItem)objectListView1.FindItemWithText(tbSearch.Text);
         * Located in tbSearch_KeyDown.
         */
        private void Search(string target)
        {
            searchResults.Clear();
            UpdateBannerSearchResults();
            listViewTasks.Items.Clear();
            try
            {
                foreach (Task task in taskList)
                {
                    if (task.getTaskName().Equals(target, StringComparison.InvariantCultureIgnoreCase))
                    {
                        searchResults.Add(task);
                    }
                    else if (task.getTaskType().Equals(target, StringComparison.InvariantCultureIgnoreCase))
                    {
                        searchResults.Add(task);
                    }
                    else if (task.getDate().Equals(target, StringComparison.InvariantCultureIgnoreCase))
                    {
                        searchResults.Add(task);
                    }
                    else if (task.getTime().Equals(target, StringComparison.InvariantCultureIgnoreCase))
                    {
                        searchResults.Add(task);
                    }
                }
                DisplayAllTasks(searchResults);
                /* 
                 * Un-comment this line to display search results in the same manner as regular listview.
                 * Without it, the object listview still highlights a matching result, even a partial match;
                 * but continues to show all entries.
                 */
                 //this.objectListView1.SetObjects(searchResults);
            }
            catch
            {
                MessageBox.Show("Not found");
            }
        }

        private void SaveFile()
        {
            SaveFileDialog sfd = new SaveFileDialog(); //Create save file dialog
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                //Name file based on filepath chosen in save file dialog
                string filePath = sfd.FileName;
                try
                {
                    using (Stream stream = File.Open(filePath, FileMode.Create))
                    {
                        BinaryFormatter bin = new BinaryFormatter(); //instantiate binary formatter
                        {
                            foreach (Task task in taskList)
                            {
                                bin.Serialize(stream, task); //serialize element
                            }
                        }
                    }

                    byte[] saveHash = File.ReadAllBytes(filePath);
                    myHash = new MD5CryptoServiceProvider().ComputeHash(saveHash);

                    using (Stream stream = File.Open(hashStoredFilePath, FileMode.Create))
                    {
                        BinaryFormatter bin = new BinaryFormatter(); //instantiate binary formatter
                        {
                            BinaryWriter br = new BinaryWriter(stream);
                            br.Write(myHash);
                        }
                    }
                }
                catch
                {
                    Console.WriteLine("Unable to save");
                }
            }
        }

        public void OpenFile()
        {
            List<Task> taskListOpen = new List<Task>();
            OpenFileDialog ofd = new OpenFileDialog();
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //pass filename into string
                string filePath = ofd.FileName;

                byte[] openHash = File.ReadAllBytes(filePath);
                byte[] newHash = MD5.Create().ComputeHash(openHash);

                bool bEqual = false;
                if (newHash.Length == myHash.Length)
                {
                    int i = 0;
                    while ((i < newHash.Length) && (newHash[i] == myHash[i]))
                    {
                        i += 1;
                    }
                    if (i == newHash.Length)
                    {
                        bEqual = true;
                    }
                }

                //Display results of hash verification
                if (bEqual)
                {
                    string match = "Hash verification matched. This is your file.";
                    Console.WriteLine(match);
                    MessageBox.Show(match);
                }
                else
                {
                    string warning = "Warning: Hash Values do not match. File may have been be altered.";
                    Console.WriteLine(warning);
                    MessageBox.Show(warning);
                }

                //Open file
                try
                {
                    using (Stream stream = File.Open(filePath, FileMode.Open)) //use stream, open file
                    {
                        BinaryFormatter bin = new BinaryFormatter(); //instantiate binary formatter
                        while (stream.Position < stream.Length) //loop to deserialise all objects in array
                        {
                            task = (Task)bin.Deserialize(stream);
                            taskListOpen.Add(task);
                        }
                        taskList = taskListOpen; //Pour temp list into regular list
                        InsertionSort(currentSortBy, taskList); //Sort list
                        DisplayAllTasks(taskList); //Display in listview
                        UpdateBannerAllTasks(); //Set banner text for sort function

                        //Display in ObjectListView aswell
                        this.objectListView1.SetObjects(taskList);
                    }
                }
                catch
                {
                    MessageBox.Show("Could not open.");
                }
            }
        }

        //Returns the integer value of a string.compare for use in the sort method.
        //Determines which task attribute to sort by (id, name, type, date, time)
        public int SelectSortCriteria(int currentIndex, string sortCriteria, Task item)
        {
            int a = 0;
            if (sortCriteria.Equals("id", StringComparison.InvariantCultureIgnoreCase))
            {
                a = string.Compare((taskList[currentIndex - 1].getID().ToString()), item.getID().ToString());
            }
            if (sortCriteria.Equals("name", StringComparison.InvariantCultureIgnoreCase))
            {
                a = string.Compare(taskList[currentIndex - 1].getTaskName(), item.getTaskName());
            }
            else if (sortCriteria.Equals("type", StringComparison.InvariantCultureIgnoreCase))
            {
                a = string.Compare(taskList[currentIndex - 1].getTaskType(), item.getTaskType());
            }
            else if (sortCriteria.Equals("date", StringComparison.InvariantCultureIgnoreCase))
            {
                a = string.Compare(taskList[currentIndex - 1].getDate(), item.getDate());
            }
            else if (sortCriteria.Equals("time", StringComparison.InvariantCultureIgnoreCase))
            {
                a = string.Compare(taskList[currentIndex - 1].getTime(), item.getTime());
            }
            return a;
        }

        //Sort method accepts sort criteria as parameter e.g. name, type, date, time
        //Uses SelectSortCriteria method
        public void InsertionSort(string sortCriteria, List<Task> taskList)
        {
            for (int i = 0; i < taskList.Count(); i++)
            {
                Task item = taskList[i];
                var currentIndex = i;

                while (currentIndex > 0 && SelectSortCriteria(currentIndex, sortCriteria, item) > 0)
                {
                    taskList[currentIndex] = taskList[currentIndex - 1];
                    currentIndex--;
                }
                taskList[currentIndex] = item;
            }
        }

        //Deletes a task by ID (regular listview)
        public void DeleteTaskByID(int target)
        {
            //Only taskIDs above this value will be decremented after a task is deleted.
            //Preserves sequence of IDs when task deleted from middle of list and prevents negative IDs.
            int taskIDBottom;
            foreach (Task task in taskList)
            {
                if (task.getID() == target)
                {
                    taskIDBottom = task.getID();
                    taskList.Remove(task); //Remove task from List

                    //Decrement all task IDs (optional)
                    foreach (Task task1 in taskList)
                    {
                        if (task1.getID() > taskIDBottom)
                        {
                            task1.setID(task1.getID() - 1);
                        }
                    }
                    break; //Exit foreach
                }
            }
        }

        //For object list view. Deletes by name.
        public void DeleteTaskByName(string target)
        {
            //Only taskIDs above this value will be decremented after a task is deleted.
            //Preserves sequence of IDs when task deleted from middle of list and prevents negative IDs.
            int taskIDBottom;
            foreach (Task task in taskList)
            {
                if (task.getTaskName() == target)
                {
                    taskIDBottom = task.getID();
                    taskList.Remove(task); //Remove task from List

                    //Decrement all task IDs (optional)
                    foreach (Task task1 in taskList)
                    {
                        if (task1.getID() > taskIDBottom)
                        {
                            task1.setID(task1.getID() - 1);
                        }
                    }
                    break; //Exit foreach
                }
            }
            this.objectListView1.SetObjects(taskList);
        }

        #endregion Methods

        #region Buttons/Form Controls

        private void btnAddTask_Click(object sender, EventArgs e)
        {
            AddTask();
        }

        //Button to return view to all tasks
        private void btnShowAllTasks_Click(object sender, EventArgs e)
        {
            DisplayAllTasks(taskList);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            Search(tbSearch.Text);
        }

        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            SaveFile();
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFile();
        }

        //Press enter in search bar to search
        private void tbSearch_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                objectListView1.SelectedItem = (BrightIdeasSoftware.OLVListItem)objectListView1.FindItemWithText(tbSearch.Text);
                Search(tbSearch.Text);
                tbSearch.Clear();
            }
        }

        //Executes sort when sort criteria chosen from drop down list.
        //Sorts either the entire task list, or only the current search results based on tbBanner status.
        private void cbSortBy_SelectedIndexChanged(object sender, EventArgs e)
        {
            currentSortBy = cbSortBy.Text;
            listViewTasks.Items.Clear();

            if (tbBanner.Text == allTasks)
            {
                InsertionSort(currentSortBy, taskList); //formerly passed "cbSortBy.Text"
                DisplayAllTasks(taskList);
            }
            else if (tbBanner.Text == searchTasks)
            {
                InsertionSort(currentSortBy, searchResults); //formerly passed "cbSortBy.Text"
                DisplayAllTasks(searchResults);
            }
        }

        //Regular list view delete function (delete by ID)
        private void listViewTasks_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            DialogResult delete = MessageBox.Show
            ("Delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (delete.Equals(DialogResult.Yes))
            {
                int target = int.Parse(listViewTasks.FocusedItem.Text);
                DeleteTaskByID(target);
                DisplayAllTasks(taskList);
                this.objectListView1.SetObjects(taskList); //Refresh object list view
            }
        }

        //Object list view delete function (delete by name)
        private void objectListView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            DialogResult delete = MessageBox.Show
            ("Delete?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (delete.Equals(DialogResult.Yes))
            {
                string target = objectListView1.FocusedItem.Text;
                DeleteTaskByName(target);
                DisplayAllTasks(taskList); //Refresh regular list view
                this.objectListView1.SetObjects(taskList);
            }
        }

        //Asks user if they want to save before closing
        private void TasksForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult leaveWithoutSaving = MessageBox.Show
            ("Leave without saving?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (leaveWithoutSaving.Equals(DialogResult.No))
            {
                SaveFile();
            }
        }

        //Interferes with delete function, now redundant************************
        //Click the name of a task to search all items with the same name
        /*private void listViewTasks_MouseClick(object sender, MouseEventArgs e)
        {
            string text = listViewTasks.FocusedItem.Text;
            Search(text);
            ListViewItem[] test = listViewTasks.Items.Find("test", false);
            for (int i = 0; i < test.Length; i++)
            {
                Console.WriteLine(test.ToString());
            }
        }*/

        #endregion Buttons/Form Controls
    }
}
