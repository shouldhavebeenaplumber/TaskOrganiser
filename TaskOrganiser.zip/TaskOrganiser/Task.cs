﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskOrganiser
{
    [Serializable]
    public class Task
    {
        private int ID;
        private string taskName;
        private string taskType;
        private string date;
        private string time;

        public void setID(int newID)
        {
            ID = newID;
        }

        public int getID()
        {
            return ID;
        }

        public void setTaskName(string newTaskName)
        {
            taskName = newTaskName;
        }

        public string getTaskName()
        {
            return taskName;
        }

        public void setTaskType(string newTaskType)
        {
            taskType = newTaskType;
        }

        public string getTaskType()
        {
            return taskType;
        }

        public void setDate(string newDate)
        {
            date = newDate;
        }

        public string getDate()
        {
            return date;
        }

        public void setTime(string newTime)
        {
            time = newTime;
        }

        public string getTime()
        {
            return time;
        }

        public string DisplayTask()
        {
            return taskName + taskType + date + time;
        }
    }
}
